import Navbar from "../components/layout/Navbar";
import Footer from "../components/layout/Footer";

function MainLayout({ children }) {

    return (

        <>

            <Navbar />

            <main className="bg-[#F8F9FA]">

                {children}

            </main>

            <Footer />

        </>

    );

}

export default MainLayout;