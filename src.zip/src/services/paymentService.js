import axiosConfig from "../utils/axiosConfig";

const pay = (data) => {
    return axiosConfig.post("/api/payments", data);
};

export default {
    pay,
};