import axiosConfig from "../utils/axiosConfig";

const getReviews = (restaurantId) => {
    return axiosConfig.get(`/api/reviews/restaurant/${restaurantId}`);
};

const addReview = (data) => {
    return axiosConfig.post("/api/reviews", data);
};

export default {
    getReviews,
    addReview,
};