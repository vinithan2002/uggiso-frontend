import axiosConfig from "../utils/axiosConfig";

const getAllRestaurants = async () => {
    const response = await axiosConfig.get("/api/restaurants");
    return response.data;
};

const getRestaurantById = async (id) => {
    const response = await axiosConfig.get(`/api/restaurants/${id}`);
    return response.data;
};

const searchRestaurants = async (keyword) => {
    const response = await axiosConfig.get(
        `/api/restaurants/search?keyword=${keyword}`
    );
    return response.data;
};

const getVegRestaurants = async () => {
    const response = await axiosConfig.get("/api/restaurants/veg");
    return response.data;
};

export default {
    getAllRestaurants,
    getRestaurantById,
    searchRestaurants,
    getVegRestaurants,
};