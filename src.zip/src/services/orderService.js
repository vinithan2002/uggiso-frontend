import axiosConfig from "../utils/axiosConfig";

const getOrdersByUser = async (userId) => {

    const response = await axiosConfig.get(
        `/api/orders/user/${userId}`
    );

    return response.data;

};

const getOrderById = async (id) => {

    const response = await axiosConfig.get(
        `/api/orders/${id}`
    );

    return response.data;

};

const cancelOrder = async (orderId) => {

    return axiosConfig.delete(
        `/api/orders/${orderId}`
    );

};

export default {

    getOrdersByUser,

    getOrderById,

    cancelOrder

};