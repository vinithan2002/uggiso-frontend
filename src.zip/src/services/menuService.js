import axiosConfig from "../utils/axiosConfig";

const getMenuByRestaurant = async (restaurantId) => {

    const response = await axiosConfig.get(
        `/api/menu-items/restaurant/${restaurantId}`
    );

    return response.data;

};

export default {

    getMenuByRestaurant

};