import axiosConfig from "../utils/axiosConfig";

const login = async (loginData) => {
    const response = await axiosConfig.post("/login", loginData);
    return response.data;
};

const register = async (registerData) => {
    const response = await axiosConfig.post("/register", registerData);
    return response.data;
};

const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("role");
};

export default {
    login,
    register,
    logout,
};