import axiosConfig from "../utils/axiosConfig";

const addToCart = async (data) => {
    const response = await axiosConfig.post("/api/cart/add", data);
    return response.data;
};

const getCart = async (userId) => {
    const response = await axiosConfig.get(`/api/cart/${userId}`);
    return response.data;
};

const updateCartItem = async (cartItemId, data) => {
    const response = await axiosConfig.put(
        `/api/cart/item/${cartItemId}`,
        data
    );
    return response.data;
};

const removeItem = async (cartItemId) => {
    return axiosConfig.delete(`/api/cart/item/${cartItemId}`);
};

export default {
    addToCart,
    getCart,
    updateCartItem,
    removeItem,
};