import axiosConfig from "../utils/axiosConfig";

const getAddresses = (userId) => {
    return axiosConfig.get(`/api/address/user/${userId}`);
};

const addAddress = (data) => {
    return axiosConfig.post("/api/address", data);
};

export default {
    getAddresses,
    addAddress,
};