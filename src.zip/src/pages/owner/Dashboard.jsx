function Dashboard() {
    return (
        <h1 className="text-4xl text-center mt-10">
            Restaurant Owner Dashboard
        </h1>
    );
}

export default Dashboard;