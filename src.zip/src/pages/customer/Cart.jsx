import { useEffect, useState } from "react";
import { ShoppingCart } from "lucide-react";

import cartService from "../../services/cartService";
import CartItem from "../../components/cart/CartItem";
import CartSummary from "../../components/cart/CartSummary";

function Cart() {

    const [cart, setCart] = useState(null);
    const [loading, setLoading] = useState(true);

    const user = JSON.parse(localStorage.getItem("user"));

    useEffect(() => {

        if (user) {

            loadCart();

        }

    }, []);

    const loadCart = async () => {

        try {

            setLoading(true);

            const data = await cartService.getCart(user.userId);

            setCart(data);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    };

    if (loading) {

        return (

            <div className="min-h-screen flex items-center justify-center">

                <h1 className="text-3xl font-bold">

                    Loading Cart...

                </h1>

            </div>

        );

    }

    if (!cart || !cart.items || cart.items.length === 0) {

        return (

            <div className="min-h-screen flex flex-col justify-center items-center">

                <ShoppingCart
                    size={90}
                    className="text-orange-500"
                />

                <h2 className="text-4xl font-bold mt-5">

                    Your Cart is Empty

                </h2>

                <p className="text-gray-500 mt-3">

                    Add delicious food to get started.

                </p>

            </div>

        );

    }

    return (

        <div className="bg-gray-100 min-h-screen py-12">

            <div className="max-w-7xl mx-auto px-6">

                <h1 className="text-4xl font-bold mb-10">

                    🛒 My Cart

                </h1>

                <div className="grid lg:grid-cols-3 gap-10">

                    {/* Cart Items */}

                    <div className="lg:col-span-2 space-y-6">

                        {

                            cart.items.map(item => (

                                <CartItem

                                    key={item.id}

                                    item={item}

                                    reloadCart={loadCart}

                                />

                            ))

                        }

                    </div>

                    {/* Summary */}

                    <CartSummary

                        cart={cart}

                    />

                </div>

            </div>

        </div>

    );

}

export default Cart;