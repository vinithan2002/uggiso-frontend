import { useState } from "react";

import HeroSection from "../../components/home/HeroSection";
import CouponSection from "../../components/home/CouponSection";
import Categories from "../../components/home/Categories";
import RestaurantGrid from "../../components/home/RestaurantGrid";

function Home() {

    const [search, setSearch] = useState("");

    return (

        <>
            <HeroSection
                search={search}
                setSearch={setSearch}
            />

            <CouponSection />

            <Categories />

            <RestaurantGrid
                search={search}
            />

        </>

    );

}

export default Home;