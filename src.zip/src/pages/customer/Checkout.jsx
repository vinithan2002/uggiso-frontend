import { useState } from "react";
import { CreditCard, MapPin, Phone } from "lucide-react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

function Checkout() {

    const navigate = useNavigate();

    const user = JSON.parse(localStorage.getItem("user"));

    const [formData, setFormData] = useState({

        address: "",
        city: "",
        pincode: "",
        phone: ""

    });

    const handleChange = (e) => {

        setFormData({

            ...formData,

            [e.target.name]: e.target.value

        });

    };

    const handlePlaceOrder = async (e) => {

        e.preventDefault();

        // Next step:
        // orderService.placeOrder(...)

        toast.success("Order Placed Successfully 🎉");

        navigate("/orders");

    };

    return (

        <div className="bg-gray-100 min-h-screen py-12">

            <div className="max-w-7xl mx-auto px-6">

                <h1 className="text-4xl font-bold mb-10">

                    Checkout

                </h1>

                <div className="grid lg:grid-cols-3 gap-10">

                    {/* Delivery Address */}

                    <div className="lg:col-span-2 bg-white rounded-3xl shadow-lg p-8">

                        <h2 className="text-2xl font-bold mb-8">

                            Delivery Address

                        </h2>

                        <form
                            onSubmit={handlePlaceOrder}
                            className="space-y-6"
                        >

                            <div>

                                <label className="font-semibold">

                                    Address

                                </label>

                                <div className="flex items-center border rounded-xl mt-2">

                                    <MapPin className="ml-4 text-orange-500" />

                                    <input
                                        type="text"
                                        name="address"
                                        value={formData.address}
                                        onChange={handleChange}
                                        className="w-full p-4 outline-none"
                                        placeholder="Enter Address"
                                    />

                                </div>

                            </div>

                            <div className="grid md:grid-cols-2 gap-5">

                                <div>

                                    <label className="font-semibold">

                                        City

                                    </label>

                                    <input
                                        type="text"
                                        name="city"
                                        value={formData.city}
                                        onChange={handleChange}
                                        className="border rounded-xl w-full p-4 mt-2 outline-none"
                                        placeholder="City"
                                    />

                                </div>

                                <div>

                                    <label className="font-semibold">

                                        Pincode

                                    </label>

                                    <input
                                        type="text"
                                        name="pincode"
                                        value={formData.pincode}
                                        onChange={handleChange}
                                        className="border rounded-xl w-full p-4 mt-2 outline-none"
                                        placeholder="Pincode"
                                    />

                                </div>

                            </div>

                            <div>

                                <label className="font-semibold">

                                    Phone

                                </label>

                                <div className="flex items-center border rounded-xl mt-2">

                                    <Phone className="ml-4 text-orange-500" />

                                    <input
                                        type="text"
                                        name="phone"
                                        value={formData.phone}
                                        onChange={handleChange}
                                        className="w-full p-4 outline-none"
                                        placeholder="Phone Number"
                                    />

                                </div>

                            </div>

                            <button
                                className="w-full bg-orange-500 hover:bg-orange-600 text-white py-4 rounded-xl text-lg font-bold"
                            >

                                Place Order

                            </button>

                        </form>

                    </div>

                    {/* Payment */}

                    <div className="bg-white rounded-3xl shadow-lg p-8 h-fit">

                        <h2 className="text-2xl font-bold mb-6">

                            Payment

                        </h2>

                        <div className="flex items-center gap-4 p-4 rounded-xl border">

                            <CreditCard className="text-orange-500" />

                            <div>

                                <h3 className="font-bold">

                                    Cash On Delivery

                                </h3>

                                <p className="text-gray-500">

                                    Pay when your order arrives

                                </p>

                            </div>

                        </div>

                        <div className="mt-8">

                            <h3 className="font-bold mb-3">

                                Customer

                            </h3>

                            <p>

                                {user.username}

                            </p>

                            <p className="text-gray-500">

                                {user.email}

                            </p>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    );

}

export default Checkout;