import { User, Mail, Shield, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

function Profile() {

    const navigate = useNavigate();

    const user = JSON.parse(localStorage.getItem("user"));

    const logout = () => {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        toast.success("Logged out successfully");

        navigate("/login");

    };

    return (

        <div className="bg-gray-100 min-h-screen py-10">

            <div className="max-w-5xl mx-auto px-6">

                <div className="bg-white rounded-3xl shadow-xl p-10">

                    <div className="flex flex-col md:flex-row items-center gap-8">

                        {/* Avatar */}

                        <div className="w-40 h-40 rounded-full bg-orange-500 flex items-center justify-center">

                            <User
                                size={80}
                                className="text-white"
                            />

                        </div>

                        {/* Details */}

                        <div className="flex-1">

                            <h1 className="text-4xl font-bold">

                                {user.username}

                            </h1>

                            <p className="text-gray-500 mt-2">

                                Welcome to UGGISO

                            </p>

                        </div>

                    </div>

                    {/* User Info */}

                    <div className="grid md:grid-cols-2 gap-8 mt-12">

                        <div className="border rounded-2xl p-6">

                            <div className="flex items-center gap-3">

                                <User className="text-orange-500" />

                                <h3 className="font-semibold">

                                    Username

                                </h3>

                            </div>

                            <p className="mt-3 text-lg">

                                {user.username}

                            </p>

                        </div>

                        <div className="border rounded-2xl p-6">

                            <div className="flex items-center gap-3">

                                <Mail className="text-orange-500" />

                                <h3 className="font-semibold">

                                    Email

                                </h3>

                            </div>

                            <p className="mt-3 text-lg">

                                {user.email}

                            </p>

                        </div>

                        <div className="border rounded-2xl p-6">

                            <div className="flex items-center gap-3">

                                <Shield className="text-orange-500" />

                                <h3 className="font-semibold">

                                    Role

                                </h3>

                            </div>

                            <p className="mt-3 text-lg">

                                {user.role}

                            </p>

                        </div>

                        <div className="border rounded-2xl p-6">

                            <div className="flex items-center gap-3">

                                <User className="text-orange-500" />

                                <h3 className="font-semibold">

                                    User ID

                                </h3>

                            </div>

                            <p className="mt-3 text-lg">

                                {user.userId}

                            </p>

                        </div>

                    </div>

                    {/* Quick Actions */}

                    <div className="grid md:grid-cols-3 gap-6 mt-12">

                        <button
                            onClick={() => navigate("/orders")}
                            className="bg-orange-500 hover:bg-orange-600 text-white py-4 rounded-xl font-semibold transition"
                        >
                            My Orders
                        </button>

                        <button
                            onClick={() => navigate("/cart")}
                            className="bg-blue-500 hover:bg-blue-600 text-white py-4 rounded-xl font-semibold transition"
                        >
                            My Cart
                        </button>

                        <button
                            onClick={logout}
                            className="bg-red-500 hover:bg-red-600 text-white py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition"
                        >
                            <LogOut size={20} />
                            Logout
                        </button>

                    </div>

                </div>

            </div>

        </div>

    );

}

export default Profile;