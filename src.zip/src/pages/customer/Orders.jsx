import { useEffect, useState } from "react";
import {
    Package,
    Calendar,
    CreditCard,
    CircleDollarSign
} from "lucide-react";
import toast from "react-hot-toast";

import orderService from "../../services/orderService";

function Orders() {

    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);

    const user = JSON.parse(localStorage.getItem("user"));

    useEffect(() => {

        loadOrders();

    }, []);

    const loadOrders = async () => {

        try {

            const data = await orderService.getOrdersByUser(
                user.userId
            );

            setOrders(data);

        } catch (error) {

            console.log(error);

            toast.error("Unable to load orders");

        } finally {

            setLoading(false);

        }

    };

    const cancelOrder = async (orderId) => {

        try {

            await orderService.cancelOrder(orderId);

            toast.success("Order Cancelled");

            loadOrders();

        }

        catch (error) {

            console.log(error);

            toast.error("Unable to cancel order");

        }

    };

    if (loading) {

        return (

            <div className="min-h-screen flex justify-center items-center">

                <h1 className="text-3xl font-bold">

                    Loading Orders...

                </h1>

            </div>

        );

    }

    return (

        <div className="bg-gray-100 min-h-screen py-10">

            <div className="max-w-7xl mx-auto px-6">

                <h1 className="text-4xl font-bold mb-10">

                    📦 My Orders

                </h1>

                {

                    orders.length === 0 ?

                        (

                            <div className="bg-white rounded-3xl shadow-lg p-16 text-center">

                                <Package
                                    size={80}
                                    className="mx-auto text-orange-500"
                                />

                                <h2 className="text-3xl font-bold mt-6">

                                    No Orders Yet

                                </h2>

                                <p className="text-gray-500 mt-3">

                                    Place your first order to see it here.

                                </p>

                            </div>

                        )

                        :

                        (

                            <div className="space-y-8">

                                {

                                    orders.map(order => (

                                        <div

                                            key={order.orderId}

                                            className="bg-white rounded-3xl shadow-lg p-8"

                                        >

                                            {/* Header */}

                                            <div className="flex justify-between items-start">

                                                <div>

                                                    <h2 className="text-2xl font-bold">

                                                        {order.orderNumber}

                                                    </h2>

                                                    <p className="text-gray-500 mt-2">

                                                        🍽 {order.restaurantName}

                                                    </p>

                                                </div>

                                                <span className="bg-green-100 text-green-700 px-4 py-2 rounded-full font-semibold">

                                                    {order.orderStatus}

                                                </span>

                                            </div>

                                            {/* Order Info */}

                                            <div className="grid md:grid-cols-3 gap-6 mt-8">

                                                <div className="flex items-center gap-3">

                                                    <Calendar className="text-orange-500" />

                                                    <div>

                                                        <p className="text-gray-500 text-sm">

                                                            Order Time

                                                        </p>

                                                        <h3>

                                                            {

                                                                new Date(

                                                                    order.orderTime

                                                                ).toLocaleString()

                                                            }

                                                        </h3>

                                                    </div>

                                                </div>

                                                <div className="flex items-center gap-3">

                                                    <CreditCard className="text-orange-500" />

                                                    <div>

                                                        <p className="text-gray-500 text-sm">

                                                            Payment

                                                        </p>

                                                        <h3>

                                                            {order.paymentMethod}

                                                        </h3>

                                                    </div>

                                                </div>

                                                <div className="flex items-center gap-3">

                                                    <CircleDollarSign className="text-orange-500" />

                                                    <div>

                                                        <p className="text-gray-500 text-sm">

                                                            Final Amount

                                                        </p>

                                                        <h3 className="font-bold text-xl text-orange-500">

                                                            ₹ {order.finalAmount}

                                                        </h3>

                                                    </div>

                                                </div>

                                            </div>

                                            {/* Ordered Items */}

                                            <div className="mt-10">

                                                <h3 className="text-xl font-bold mb-4">

                                                    Ordered Items

                                                </h3>

                                                <div className="space-y-3">

                                                    {

                                                        order.orderItems.map(item => (

                                                            <div

                                                                key={item.menuItemId}

                                                                className="flex justify-between border-b pb-3"

                                                            >

                                                                <div>

                                                                    <h4 className="font-semibold">

                                                                        {item.menuItemName}

                                                                    </h4>

                                                                    <p className="text-gray-500">

                                                                        Qty :

                                                                        {" "}

                                                                        {item.quantity}

                                                                    </p>

                                                                </div>

                                                                <h4 className="font-semibold">

                                                                    ₹ {item.subTotal}

                                                                </h4>

                                                            </div>

                                                        ))

                                                    }

                                                </div>

                                            </div>

                                            {/* Cancel */}

                                            {

                                                order.orderStatus === "PLACED" && (

                                                    <button

                                                        onClick={() =>
                                                            cancelOrder(order.orderId)
                                                        }

                                                        className="mt-8 bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-xl transition"

                                                    >

                                                        Cancel Order

                                                    </button>

                                                )

                                            }

                                        </div>

                                    ))

                                }

                            </div>

                        )

                }

            </div>

        </div>

    );

}

export default Orders;