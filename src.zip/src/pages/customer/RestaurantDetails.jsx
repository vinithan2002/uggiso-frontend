import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Star, Clock3, MapPin } from "lucide-react";

import restaurantService from "../../services/restaurantService";
import menuService from "../../services/menuService";
import MenuCard from "../../components/restaurant/MenuCard";
import cartService from "../../services/cartService";
import toast from "react-hot-toast";

function RestaurantDetails() {

    const { id } = useParams();

    const [restaurant, setRestaurant] = useState(null);
    const [menuItems, setMenuItems] = useState([]);
    const [loading, setLoading] = useState(true);

    const user = JSON.parse(localStorage.getItem("user"));
    useEffect(() => {

        loadRestaurant();

    }, [id]);

const handleAddToCart = async (item) => {

    if (!user) {

        toast.error("Please login first");

        return;

    }

    try {

        await cartService.addToCart({

            userId: user.userId,
            menuItemId: item.id,
            quantity: 1

        });

        toast.success(`${item.name} added to cart`);

    } catch (error) {

        console.error(error);

        toast.error("Failed to add to cart");

    }

};
    const loadRestaurant = async () => {

        try {

            setLoading(true);

            const restaurantData =
                await restaurantService.getRestaurantById(id);

            const menuData =
                await menuService.getMenuByRestaurant(id);

            setRestaurant(restaurantData);

            setMenuItems(menuData);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    };

    if (loading) {

        return (

            <div className="min-h-screen flex justify-center items-center">

                <h1 className="text-3xl font-bold">

                    Loading...

                </h1>

            </div>

        );

    }

    return (

        <div className="bg-gray-50 min-h-screen">

            {/* Banner */}

            <div className="relative h-[450px]">

                <img
                    src={
                        restaurant.imageUrl ||
                        "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1600"
                    }
                    alt={restaurant.name}
                    className="w-full h-full object-cover"
                />

                <div className="absolute inset-0 bg-black/60" />

                <div className="absolute bottom-10 left-1/2 -translate-x-1/2 max-w-7xl w-full px-6 text-white">

                    <h1 className="text-5xl font-black">

                        {restaurant.name}

                    </h1>

                    <p className="mt-4 text-lg">

                        {restaurant.description}

                    </p>

                    <div className="flex flex-wrap gap-8 mt-6">

                        <div className="flex items-center gap-2">

                            <Star
                                className="text-yellow-400"
                                fill="gold"
                            />

                            {restaurant.rating}

                        </div>

                        <div className="flex items-center gap-2">

                            <Clock3 />

                            {restaurant.deliveryTime} mins

                        </div>

                        <div className="flex items-center gap-2">

                            <MapPin />

                            {restaurant.city}

                        </div>

                        <div>

                            ₹{restaurant.minimumOrder} Minimum Order

                        </div>

                    </div>

                </div>

            </div>

            {/* Menu */}

            <div className="max-w-7xl mx-auto py-16 px-6">

                <h2 className="text-4xl font-bold mb-10">

                    🍽 Menu

                </h2>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

                    {

                        menuItems.map(item => (

                            <MenuCard

                                key={item.id}

                                item={item}

                                onAdd={handleAddToCart}

                            />

                        ))

                    }

                </div>

            </div>

        </div>

    );

}

export default RestaurantDetails;