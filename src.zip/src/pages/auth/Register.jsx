import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { User, Mail, Lock, Phone } from "lucide-react";
import { useAuth } from "../../context/AuthContext";

function Register() {

    const navigate = useNavigate();

    const { register, loading } = useAuth();

    const [formData, setFormData] = useState({

        firstName: "",
        lastName: "",
        userName: "",
        email: "",
        phoneNumber: "",
        password: ""

    });

    const handleChange = (e) => {

        setFormData({

            ...formData,

            [e.target.name]: e.target.value

        });

    };

    const handleSubmit = async (e) => {

        e.preventDefault();

        const result = await register(formData);

        if (result.success) {

            alert("Registration Successful");

            navigate("/login");

        } else {

            alert(result.message);

        }

    };

    return (

        <div className="min-h-screen bg-orange-50 flex justify-center items-center p-10">

            <form
                onSubmit={handleSubmit}
                className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl p-10"
            >

                <h2 className="text-4xl font-bold text-center">

                    Create Account

                </h2>

                <div className="grid md:grid-cols-2 gap-6 mt-8">

                    <Input
                        icon={<User size={18}/>}
                        name="firstName"
                        placeholder="First Name"
                        value={formData.firstName}
                        onChange={handleChange}
                    />

                    <Input
                        icon={<User size={18}/>}
                        name="lastName"
                        placeholder="Last Name"
                        value={formData.lastName}
                        onChange={handleChange}
                    />

                    <Input
                        icon={<User size={18}/>}
                        name="userName"
                        placeholder="Username"
                        value={formData.userName}
                        onChange={handleChange}
                    />

                    <Input
                        icon={<Mail size={18}/>}
                        name="email"
                        placeholder="Email"
                        value={formData.email}
                        onChange={handleChange}
                    />

                    <Input
                        icon={<Phone size={18}/>}
                        name="phoneNumber"
                        placeholder="Phone Number"
                        value={formData.phoneNumber}
                        onChange={handleChange}
                    />

                    <Input
                        icon={<Lock size={18}/>}
                        type="password"
                        name="password"
                        placeholder="Password"
                        value={formData.password}
                        onChange={handleChange}
                    />

                </div>

                <button
                    className="w-full mt-8 bg-orange-500 hover:bg-orange-600 text-white py-4 rounded-xl font-bold"
                >

                    {loading ? "Creating..." : "Create Account"}

                </button>

                <p className="text-center mt-6">

                    Already have an account?

                    <Link
                        to="/login"
                        className="text-orange-500 ml-2 font-semibold"
                    >

                        Login

                    </Link>

                </p>

            </form>

        </div>

    );

}

function Input({
    icon,
    type = "text",
    ...props
}) {

    return (

        <div className="flex items-center border rounded-xl">

            <div className="px-4 text-gray-400">

                {icon}

            </div>

            <input
                type={type}
                {...props}
                className="w-full p-4 outline-none"
            />

        </div>

    );

}

export default Register;