import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock } from "lucide-react";
import { useAuth } from "../../context/AuthContext";

function Login() {

    const navigate = useNavigate();
    const { login, loading } = useAuth();

    const [loginData, setLoginData] = useState({
        userName: "",
        password: ""
    });

    const handleChange = (e) => {
        setLoginData({
            ...loginData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {

        e.preventDefault();

        const result = await login(loginData);

        if (result.success) {

            switch (result.role) {

                case "ROLE_USER":
                    navigate("/");
                    break;

                case "ROLE_RESTAURANT_OWNER":
                    navigate("/owner/dashboard");
                    break;

                case "ROLE_DELIVERY_AGENT":
                    navigate("/delivery/dashboard");
                    break;

                default:
                    navigate("/");
            }

        } else {

            alert(result.message);

        }

    };

    return (

        <div className="min-h-screen grid lg:grid-cols-2">

            {/* Left */}

            <div
                className="hidden lg:flex bg-cover bg-center"
                style={{
                    backgroundImage:
                        "url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1200')"
                }}
            >

                <div className="bg-black/60 w-full flex flex-col justify-center items-center text-white p-12">

                    <h1 className="text-6xl font-black">

                        UGGISO

                    </h1>

                    <p className="text-xl mt-6 text-center">

                        Delicious food delivered
                        <br />
                        at your doorstep.

                    </p>

                </div>

            </div>

            {/* Right */}

            <div className="flex justify-center items-center bg-orange-50 p-8">

                <form
                    onSubmit={handleSubmit}
                    className="bg-white rounded-3xl shadow-2xl p-10 w-full max-w-md"
                >

                    <h2 className="text-4xl font-bold text-center">

                        Welcome Back

                    </h2>

                    <p className="text-center text-gray-500 mt-3">

                        Login to continue

                    </p>

                    <div className="mt-8">

                        <label className="font-semibold">

                            Username

                        </label>

                        <div className="flex items-center border rounded-xl mt-2">

                            <Mail className="ml-4 text-gray-400" />

                            <input
                                type="text"
                                name="userName"
                                value={loginData.userName}
                                onChange={handleChange}
                                placeholder="Enter Username"
                                className="w-full p-4 outline-none"
                            />

                        </div>

                    </div>

                    <div className="mt-5">

                        <label className="font-semibold">

                            Password

                        </label>

                        <div className="flex items-center border rounded-xl mt-2">

                            <Lock className="ml-4 text-gray-400" />

                            <input
                                type="password"
                                name="password"
                                value={loginData.password}
                                onChange={handleChange}
                                placeholder="Enter Password"
                                className="w-full p-4 outline-none"
                            />

                        </div>

                    </div>

                    <button
                        disabled={loading}
                        className="w-full mt-8 bg-orange-500 hover:bg-orange-600 text-white py-4 rounded-xl font-bold transition"
                    >

                        {loading ? "Logging in..." : "Login"}

                    </button>

                    <p className="text-center mt-6">

                        Don't have an account?

                        <Link
                            to="/register"
                            className="text-orange-500 font-semibold ml-2"
                        >
                            Register
                        </Link>

                    </p>

                </form>

            </div>

        </div>

    );

}

export default Login;