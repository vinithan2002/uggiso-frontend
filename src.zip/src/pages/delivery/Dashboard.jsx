function Dashboard() {
    return (
        <h1 className="text-4xl text-center mt-10">
            Delivery Dashboard
        </h1>
    );
}

export default Dashboard;