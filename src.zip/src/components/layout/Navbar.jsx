import { Link, useNavigate } from "react-router-dom";
import {
    Search,
    ShoppingCart,
    ClipboardList,
    User,
    LogOut,
    Menu,
    X
} from "lucide-react";
import { useState, useEffect } from "react";

import { useAuth } from "../../context/AuthContext";
import cartService from "../../services/cartService";

function Navbar() {

    const { logout } = useAuth();
    const navigate = useNavigate();

    const [mobileMenu, setMobileMenu] = useState(false);
    const [cartCount, setCartCount] = useState(0);

    const user = JSON.parse(localStorage.getItem("user"));

    useEffect(() => {

        loadCart();

    }, []);

    const loadCart = async () => {

        if (!user) return;

        try {

            const cart = await cartService.getCart(user.userId);

            setCartCount(cart.totalItems || 0);

        } catch (error) {

            console.log(error);

        }

    };

    const handleLogout = () => {

        logout();

        navigate("/login");

    };

    return (

        <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md shadow-sm border-b">

            <div className="max-w-7xl mx-auto h-20 flex items-center justify-between px-6">

                {/* Logo */}

                <Link
                    to="/"
                    className="flex items-center gap-3"
                >

                    <div className="w-12 h-12 rounded-full bg-orange-500 flex items-center justify-center text-white text-2xl">

                        🍕

                    </div>

                    <div>

                        <h1 className="text-2xl font-black">

                            UGGISO

                        </h1>

                        <p className="text-xs text-gray-500">

                            Food Delivery

                        </p>

                    </div>

                </Link>

                {/* Search */}

                <div className="hidden lg:flex items-center bg-gray-100 rounded-full px-5 py-3 w-[450px]">

                    <Search
                        size={20}
                        className="text-gray-500"
                    />

                    <input
                        type="text"
                        placeholder="Search restaurants..."
                        className="bg-transparent outline-none w-full px-3"
                    />

                </div>

                {/* Desktop Menu */}

                <div className="hidden md:flex items-center gap-8">

                    <Link
                        to="/orders"
                        className="flex items-center gap-2 hover:text-orange-500 transition"
                    >

                        <ClipboardList size={22} />

                        Orders

                    </Link>

                    <Link
                        to="/cart"
                        className="relative hover:text-orange-500 transition"
                    >

                        <ShoppingCart size={25} />

                        {

                            cartCount > 0 && (

                                <span className="absolute -top-2 -right-2 bg-orange-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-semibold">

                                    {cartCount}

                                </span>

                            )

                        }

                    </Link>

                    <Link
                        to="/profile"
                        className="hover:text-orange-500 transition"
                    >

                        <User size={25} />

                    </Link>

                    <button
                        onClick={handleLogout}
                        className="flex items-center gap-2 text-red-500 hover:text-red-600"
                    >

                        <LogOut size={20} />

                        Logout

                    </button>

                </div>

                {/* Mobile Menu Button */}

                <button
                    className="md:hidden"
                    onClick={() => setMobileMenu(!mobileMenu)}
                >

                    {

                        mobileMenu ?

                            <X />

                            :

                            <Menu />

                    }

                </button>

            </div>

            {/* Mobile Menu */}

            {

                mobileMenu && (

                    <div className="md:hidden bg-white border-t">

                        <div className="flex flex-col gap-5 p-6">

                            <Link
                                to="/orders"
                                onClick={() => setMobileMenu(false)}
                            >

                                Orders

                            </Link>

                            <Link
                                to="/cart"
                                onClick={() => setMobileMenu(false)}
                            >

                                Cart

                                {

                                    cartCount > 0 && (

                                        <span className="ml-2 bg-orange-500 text-white px-2 rounded-full text-xs">

                                            {cartCount}

                                        </span>

                                    )

                                }

                            </Link>

                            <Link
                                to="/profile"
                                onClick={() => setMobileMenu(false)}
                            >

                                Profile

                            </Link>

                            <button
                                onClick={handleLogout}
                                className="text-left text-red-500"
                            >

                                Logout

                            </button>

                        </div>

                    </div>

                )

            }

        </header>

    );

}

export default Navbar;