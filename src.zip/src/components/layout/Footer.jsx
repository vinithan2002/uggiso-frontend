import { Link } from "react-router-dom";
import {
    FaFacebookF,
    FaInstagram,
    FaTwitter,
    FaGithub,
    FaPhoneAlt,
    FaEnvelope,
    FaMapMarkerAlt
} from "react-icons/fa";

function Footer() {
    return (
        <footer className="bg-gray-900 text-white mt-20">

            <div className="max-w-7xl mx-auto px-6 py-14">

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">

                    {/* Company */}

                    <div>

                        <h2 className="text-3xl font-extrabold text-orange-500">
                            🍕 UGGISO
                        </h2>

                        <p className="text-gray-400 mt-5 leading-7">
                            UGGISO is your trusted food delivery platform,
                            bringing delicious meals from your favourite
                            restaurants directly to your doorstep.
                        </p>

                    </div>

                    {/* Quick Links */}

                    <div>

                        <h3 className="text-xl font-semibold mb-5">
                            Quick Links
                        </h3>

                        <ul className="space-y-3 text-gray-400">

                            <li>
                                <Link
                                    to="/"
                                    className="hover:text-orange-500 transition"
                                >
                                    Home
                                </Link>
                            </li>

                            <li>
                                <Link
                                    to="/orders"
                                    className="hover:text-orange-500 transition"
                                >
                                    My Orders
                                </Link>
                            </li>

                            <li>
                                <Link
                                    to="/cart"
                                    className="hover:text-orange-500 transition"
                                >
                                    Cart
                                </Link>
                            </li>

                            <li>
                                <Link
                                    to="/profile"
                                    className="hover:text-orange-500 transition"
                                >
                                    Profile
                                </Link>
                            </li>

                        </ul>

                    </div>

                    {/* Contact */}

                    <div>

                        <h3 className="text-xl font-semibold mb-5">
                            Contact Us
                        </h3>

                        <div className="space-y-4 text-gray-400">

                            <div className="flex items-center gap-3">

                                <FaPhoneAlt className="text-orange-500" />

                                <span>+91 98765 43210</span>

                            </div>

                            <div className="flex items-center gap-3">

                                <FaEnvelope className="text-orange-500" />

                                <span>support@uggiso.com</span>

                            </div>

                            <div className="flex items-center gap-3">

                                <FaMapMarkerAlt className="text-orange-500" />

                                <span>Bengaluru, Karnataka</span>

                            </div>

                        </div>

                    </div>

                    {/* Social Media */}

                    <div>

                        <h3 className="text-xl font-semibold mb-5">
                            Follow Us
                        </h3>

                        <div className="flex gap-4">

                            <a
                                href="#"
                                className="w-11 h-11 bg-gray-800 rounded-full flex items-center justify-center hover:bg-orange-500 transition duration-300"
                            >
                                <FaFacebookF />
                            </a>

                            <a
                                href="#"
                                className="w-11 h-11 bg-gray-800 rounded-full flex items-center justify-center hover:bg-orange-500 transition duration-300"
                            >
                                <FaInstagram />
                            </a>

                            <a
                                href="#"
                                className="w-11 h-11 bg-gray-800 rounded-full flex items-center justify-center hover:bg-orange-500 transition duration-300"
                            >
                                <FaTwitter />
                            </a>

                            <a
                                href="#"
                                className="w-11 h-11 bg-gray-800 rounded-full flex items-center justify-center hover:bg-orange-500 transition duration-300"
                            >
                                <FaGithub />
                            </a>

                        </div>

                    </div>

                </div>

                {/* Bottom */}

                <div className="border-t border-gray-700 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center text-gray-400 text-sm">

                    <p>
                        © {new Date().getFullYear()} UGGISO. All Rights Reserved.
                    </p>

                    <p className="mt-3 md:mt-0">
                        Made with ❤️ using React & Spring Boot
                    </p>

                </div>

            </div>

        </footer>
    );
}

export default Footer;