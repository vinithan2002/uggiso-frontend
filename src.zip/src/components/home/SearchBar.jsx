import { FaSearch } from "react-icons/fa";

function SearchBar({ search, setSearch }) {

    return (

        <div className="max-w-3xl mx-auto mt-10">

            <div className="flex border rounded-xl overflow-hidden shadow">

                <input
                    type="text"
                    placeholder="Search Restaurants..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="flex-1 p-4 outline-none"
                />

                <button className="bg-red-600 text-white px-6">
                    <FaSearch />
                </button>

            </div>

        </div>

    );

}

export default SearchBar;