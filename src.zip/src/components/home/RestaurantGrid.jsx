import { useEffect, useState } from "react";
import restaurantService from "../../services/restaurantService";
import RestaurantCard from "../restaurant/RestaurantCard";
import { UtensilsCrossed } from "lucide-react";

function RestaurantGrid({ search }) {

    const [restaurants, setRestaurants] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {

        fetchRestaurants();

    }, []);

    const fetchRestaurants = async () => {

        try {

            setLoading(true);

            const data =
                await restaurantService.getAllRestaurants();

            setRestaurants(data);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    };

    const filteredRestaurants =
        restaurants.filter((restaurant) =>
            restaurant.name
                ?.toLowerCase()
                .includes(search.toLowerCase())
        );

    return (

        <section className="py-20 bg-gray-50">

            <div className="max-w-7xl mx-auto px-6">

                {/* Heading */}

                <div className="flex flex-col md:flex-row justify-between items-center mb-10">

                    <div>

                        <h2 className="text-4xl font-bold text-gray-800">

                            🍽 Popular Restaurants

                        </h2>

                        <p className="text-gray-500 mt-2">

                            {filteredRestaurants.length} Restaurants Available

                        </p>

                    </div>

                </div>

                {/* Loading */}

                {
                    loading && (

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">

                            {
                                [...Array(8)].map((_, index) => (

                                    <div
                                        key={index}
                                        className="bg-white rounded-3xl h-96 animate-pulse"
                                    />

                                ))
                            }

                        </div>

                    )
                }

                {/* No Restaurants */}

                {
                    !loading &&
                    filteredRestaurants.length === 0 && (

                        <div className="bg-white rounded-3xl p-16 text-center shadow">

                            <UtensilsCrossed
                                size={70}
                                className="mx-auto text-orange-500"
                            />

                            <h2 className="text-3xl font-bold mt-5">

                                No Restaurants Found

                            </h2>

                            <p className="text-gray-500 mt-3">

                                Try searching with another keyword.

                            </p>

                        </div>

                    )
                }

                {/* Restaurants */}

                {
                    !loading &&
                    filteredRestaurants.length > 0 && (

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">

                            {
                                filteredRestaurants.map((restaurant) => (

                                    <RestaurantCard
                                        key={restaurant.id}
                                        restaurant={restaurant}
                                    />

                                ))
                            }

                        </div>

                    )
                }

            </div>

        </section>

    );

}

export default RestaurantGrid;