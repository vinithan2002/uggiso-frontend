import { Copy, ChevronLeft, ChevronRight } from "lucide-react";
import { useRef } from "react";
import toast from "react-hot-toast";

const coupons = [
    {
        id: 1,
        title: "WELCOME50",
        discount: "50% OFF",
        description: "On your first order",
        color: "from-orange-500 to-red-500",
        icon: "🎉"
    },
    {
        id: 2,
        title: "FREEDEL",
        discount: "FREE DELIVERY",
        description: "Orders above ₹499",
        color: "from-green-500 to-emerald-600",
        icon: "🚚"
    },
    {
        id: 3,
        title: "SAVE100",
        discount: "₹100 OFF",
        description: "Orders above ₹399",
        color: "from-blue-500 to-indigo-600",
        icon: "💸"
    },
    {
        id: 4,
        title: "COMBO20",
        discount: "20% OFF",
        description: "Special Combo Meals",
        color: "from-purple-500 to-pink-600",
        icon: "🍔"
    }
];

function CouponSection() {

    const scrollRef = useRef(null);

    const copyCoupon = (coupon) => {

        navigator.clipboard.writeText(coupon);

        toast.success(`${coupon} copied successfully`);

    };

    const scrollLeft = () => {

        scrollRef.current?.scrollBy({
            left: -350,
            behavior: "smooth"
        });

    };

    const scrollRight = () => {

        scrollRef.current?.scrollBy({
            left: 350,
            behavior: "smooth"
        });

    };

    return (

        <section className="py-20 bg-gray-50">

            <div className="max-w-7xl mx-auto px-6">

                <div className="flex justify-between items-center mb-10">

                    <div>

                        <h2 className="text-4xl font-bold text-gray-800">

                            🔥 Exclusive Offers

                        </h2>

                        <p className="text-gray-500 mt-2">

                            Save more with amazing coupons.

                        </p>

                    </div>

                    <div className="flex gap-3">

                        <button
                            onClick={scrollLeft}
                            className="bg-white shadow-lg rounded-full p-3 hover:bg-orange-500 hover:text-white transition"
                        >
                            <ChevronLeft />
                        </button>

                        <button
                            onClick={scrollRight}
                            className="bg-white shadow-lg rounded-full p-3 hover:bg-orange-500 hover:text-white transition"
                        >
                            <ChevronRight />
                        </button>

                    </div>

                </div>

                <div
                    ref={scrollRef}
                    className="flex gap-6 overflow-x-auto scrollbar-hide scroll-smooth pb-3"
                >

                    {
                        coupons.map(coupon => (

                            <div
                                key={coupon.id}
                                className={`min-w-[340px] rounded-3xl bg-gradient-to-r ${coupon.color} text-white p-8 shadow-xl hover:scale-105 transition duration-300 relative overflow-hidden`}
                            >

                                <div className="absolute right-5 top-3 text-7xl opacity-20">

                                    {coupon.icon}

                                </div>

                                <h2 className="text-4xl font-black">

                                    {coupon.discount}

                                </h2>

                                <p className="mt-3 text-lg">

                                    {coupon.description}

                                </p>

                                <div className="mt-8 flex justify-between items-center">

                                    <span className="bg-white/20 rounded-full px-5 py-2 font-mono">

                                        {coupon.title}

                                    </span>

                                    <button

                                        onClick={() => copyCoupon(coupon.title)}

                                        className="bg-white/20 hover:bg-white/30 rounded-full p-3 transition"

                                    >

                                        <Copy size={18} />

                                    </button>

                                </div>

                            </div>

                        ))
                    }

                </div>

            </div>

        </section>

    );

}

export default CouponSection;