import { Search, MapPin, ArrowRight } from "lucide-react";

function HeroSection({ search, setSearch }) {
    return (
        <section className="relative h-[92vh] w-full overflow-hidden">

            {/* Background Video */}
            <video
                autoPlay
                loop
                muted
                playsInline
                className="absolute inset-0 w-full h-full object-cover"
            >
                <source
                    src="https://b.zmtcdn.com/data/file_assets/2627bbed9d6c068e50d2aadcca11ddbb1743095810.mp4"
                    type="video/mp4"
                />
            </video>

            {/* Dark Overlay */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>

            {/* Hero Content */}
            <div className="relative z-10 h-full flex items-center">

                <div className="max-w-7xl mx-auto w-full px-6">

                    <div className="max-w-3xl">

                        <span className="bg-orange-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
                            🍕 India's Fastest Food Delivery
                        </span>

                        <h1 className="mt-6 text-6xl md:text-7xl font-extrabold text-white leading-tight">
                            Good Food
                            <br />
                            Delivered
                            <span className="text-orange-500">
                                {" "}Fast
                            </span>
                        </h1>

                        <p className="text-gray-200 mt-6 text-xl leading-8">
                            Discover the best restaurants near you.
                            Fresh food, exciting offers, and lightning-fast delivery.
                        </p>

                        {/* Search Box */}

                        <div className="bg-white rounded-2xl shadow-2xl mt-10 p-3 flex flex-col lg:flex-row gap-3">

                            <div className="flex items-center flex-1 border rounded-xl px-4">

                                <MapPin className="text-orange-500" />

                                <input
                                    type="text"
                                    placeholder="Enter your location"
                                    className="flex-1 p-4 outline-none"
                                />

                            </div>

                            <div className="flex items-center flex-[2] border rounded-xl px-4">

                                <Search className="text-gray-500" />

                                <input
                                    type="text"
                                    placeholder="Search restaurants, cuisines..."
                                    value={search}
                                    onChange={(e) => setSearch(e.target.value)}
                                    className="flex-1 p-4 outline-none"
                                />

                            </div>

                            <button
                                className="bg-orange-500 hover:bg-orange-600 transition text-white px-8 rounded-xl flex items-center justify-center gap-2"
                            >
                                Search
                                <ArrowRight size={20} />
                            </button>

                        </div>

                        {/* Stats */}

                        <div className="flex gap-10 mt-12 text-white">

                            <div>

                                <h2 className="text-4xl font-bold">
                                    500+
                                </h2>

                                <p className="text-gray-300">
                                    Restaurants
                                </p>

                            </div>

                            <div>

                                <h2 className="text-4xl font-bold">
                                    50K+
                                </h2>

                                <p className="text-gray-300">
                                    Happy Customers
                                </p>

                            </div>

                            <div>

                                <h2 className="text-4xl font-bold">
                                    30 min
                                </h2>

                                <p className="text-gray-300">
                                    Average Delivery
                                </p>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </section>
    );
}

export default HeroSection;