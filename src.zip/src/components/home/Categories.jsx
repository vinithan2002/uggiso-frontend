const categories = [
    {
        name: "Pizza",
        image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=300"
    },
    {
        name: "Burger",
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300"
    },
    {
        name: "Biryani",
        image: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=300"
    },
    {
        name: "Chinese",
        image: "https://images.unsplash.com/photo-1563245372-f21724e3856d?w=300"
    },
    {
        name: "Desserts",
        image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=300"
    },
    {
        name: "Cafe",
        image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=300"
    },
    {
        name: "South Indian",
        image: "https://images.unsplash.com/photo-1630383249896-424e482df921?w=300"
    },
    {
        name: "North Indian",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=300"
    }
];

function Categories() {

    return (

        <section className="py-20 bg-white">

            <div className="max-w-7xl mx-auto px-6">

                {/* Heading */}

                <div className="text-center mb-12">

                    <h2 className="text-4xl font-bold text-gray-800">

                        🍽️ Explore Categories

                    </h2>

                    <p className="text-gray-500 mt-3 text-lg">

                        Choose your favourite food and enjoy delicious meals.

                    </p>

                </div>

                {/* Categories */}

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-8">

                    {
                        categories.map((category) => (

                            <div
                                key={category.name}
                                className="group cursor-pointer text-center"
                            >

                                <div
                                    className="
                                        w-28 h-28
                                        mx-auto
                                        rounded-full
                                        overflow-hidden
                                        shadow-lg
                                        border-4 border-white
                                        group-hover:scale-110
                                        group-hover:shadow-2xl
                                        transition-all
                                        duration-300
                                    "
                                >

                                    <img
                                        src={category.image}
                                        alt={category.name}
                                        className="w-full h-full object-cover"
                                    />

                                </div>

                                <h3
                                    className="
                                        mt-4
                                        font-semibold
                                        text-gray-700
                                        group-hover:text-orange-500
                                        transition
                                    "
                                >
                                    {category.name}
                                </h3>

                            </div>

                        ))
                    }

                </div>

            </div>

        </section>

    );

}

export default Categories;