import { useNavigate } from "react-router-dom";

function CartSummary({ cart }) {

    const navigate = useNavigate();

    return (

        <div className="bg-white rounded-3xl shadow-lg p-8 h-fit sticky top-28">

            <h2 className="text-3xl font-bold mb-8">

                Order Summary

            </h2>

            <div className="space-y-5">

                <div className="flex justify-between">

                    <span>

                        Total Items

                    </span>

                    <span>

                        {cart.totalItems}

                    </span>

                </div>

                <div className="flex justify-between text-xl font-bold">

                    <span>

                        Total Amount

                    </span>

                    <span className="text-orange-500">

                        ₹ {cart.totalAmount}

                    </span>

                </div>

            </div>

            <button

                onClick={() => navigate("/checkout")}

                className="w-full mt-8 bg-orange-500 hover:bg-orange-600 text-white py-4 rounded-xl font-bold transition"

            >

                Proceed to Checkout

            </button>

        </div>

    );

}

export default CartSummary;