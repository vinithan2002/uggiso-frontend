import { Minus, Plus, Trash2 } from "lucide-react";
import cartService from "../../services/cartService";
import toast from "react-hot-toast";

function CartItem({ item, reloadCart }) {

    const updateQuantity = async (quantity) => {

        if (quantity < 1) return;

        try {

            await cartService.updateCartItem(

                item.cartItemId,

                {
                    quantity
                }

            );

            reloadCart();

        } catch (error) {

            console.error(error);

            toast.error("Failed to update quantity");

        }

    };

    const removeItem = async () => {

        try {

            await cartService.removeItem(

                item.cartItemId

            );

            toast.success("Item removed");

            reloadCart();

        } catch (error) {

            console.error(error);

            toast.error("Failed to remove item");

        }

    };

    return (

        <div className="bg-white rounded-3xl shadow-md p-6 flex justify-between items-center">

            <div>

                <h2 className="text-2xl font-bold">

                    {item.menuItemName}

                </h2>

                <p className="text-gray-500 mt-2">

                    ₹ {item.price}

                </p>

                <div className="flex items-center gap-4 mt-5">

                    <button

                        onClick={() =>
                            updateQuantity(item.quantity - 1)
                        }

                        className="bg-gray-200 rounded-full p-2"

                    >

                        <Minus size={18} />

                    </button>

                    <span className="font-bold text-xl">

                        {item.quantity}

                    </span>

                    <button

                        onClick={() =>
                            updateQuantity(item.quantity + 1)
                        }

                        className="bg-orange-500 text-white rounded-full p-2"

                    >

                        <Plus size={18} />

                    </button>

                </div>

            </div>

            <div className="text-right">

                <button

                    onClick={removeItem}

                    className="text-red-500"

                >

                    <Trash2 />

                </button>

                <h2 className="text-2xl font-bold text-orange-500 mt-8">

                    ₹ {item.subTotal}

                </h2>

            </div>

        </div>

    );

}

export default CartItem;