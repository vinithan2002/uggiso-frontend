import { Link } from "react-router-dom";
import {
    Star,
    Clock3,
    Heart,
    MapPin
} from "lucide-react";

function RestaurantCard({ restaurant }) {

    return (

        <Link
            to={`/restaurant/${restaurant.id}`}
            className="group"
        >

            <div className="bg-white rounded-3xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">

                {/* Image */}

                <div className="relative overflow-hidden h-60">

                    <img
                        src={
                            restaurant.imageUrl ||
                            "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600"
                        }
                        alt={restaurant.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
                    />

                    {/* Favorite */}

                    <button
                        className="absolute top-4 right-4 bg-white/90 rounded-full p-2 shadow-lg hover:bg-red-500 hover:text-white transition"
                    >
                        <Heart size={18} />
                    </button>

                    {/* Rating */}

                    <div
                        className="
                            absolute
                            left-4
                            bottom-4
                            bg-green-600
                            text-white
                            px-3
                            py-1
                            rounded-full
                            flex
                            items-center
                            gap-1
                            text-sm
                            font-semibold
                        "
                    >

                        <Star
                            size={14}
                            fill="white"
                        />

                        {restaurant.rating || "4.5"}

                    </div>

                </div>

                {/* Content */}

                <div className="p-5">

                    <div className="flex justify-between items-start">

                        <div>

                            <h2 className="text-xl font-bold text-gray-800">

                                {restaurant.name}

                            </h2>

                            <p className="text-gray-500 mt-1">

                                {restaurant.cuisine}

                            </p>

                        </div>

                        {
                            restaurant.vegOnly && (

                                <span className="text-green-600 font-semibold">

                                    🟢 Veg

                                </span>

                            )
                        }

                    </div>

                    <div className="flex items-center gap-2 text-gray-500 mt-4">

                        <MapPin
                            size={16}
                        />

                        <span>

                            {restaurant.city}

                        </span>

                    </div>

                    <div className="flex justify-between mt-5">

                        <div className="flex items-center gap-2">

                            <Clock3
                                size={18}
                                className="text-orange-500"
                            />

                            <span>

                                {restaurant.deliveryTime} mins

                            </span>

                        </div>

                        <span className="font-semibold text-orange-500">

                            ₹{restaurant.minimumOrder}

                        </span>

                    </div>

                    <button
                        className="
                            mt-6
                            w-full
                            bg-orange-500
                            hover:bg-orange-600
                            text-white
                            py-3
                            rounded-xl
                            font-semibold
                            transition
                        "
                    >

                        View Menu

                    </button>

                </div>

            </div>

        </Link>

    );

}

export default RestaurantCard;