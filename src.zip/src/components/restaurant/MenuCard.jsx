import { Clock3, Plus, Star } from "lucide-react";

function MenuCard({ item, onAdd }) {

    return (

        <div className="bg-white rounded-3xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 group">

            {/* Food Image */}

            <div className="relative h-60 overflow-hidden">

                <img
                    src={
                        item.imageUrl ||
                        "https://images.unsplash.com/photo-1544025162-d76694265947?w=700"
                    }
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
                />

                {/* Veg / Non Veg */}

                <div className="absolute top-4 left-4">

                    {
                        item.veg ?

                            <span className="bg-green-600 text-white px-3 py-1 rounded-full text-sm font-semibold">

                                🟢 Veg

                            </span>

                            :

                            <span className="bg-red-600 text-white px-3 py-1 rounded-full text-sm font-semibold">

                                🔴 Non Veg

                            </span>

                    }

                </div>

                {/* Rating */}

                <div className="absolute bottom-4 left-4 bg-green-600 text-white px-3 py-1 rounded-full flex items-center gap-1">

                    <Star
                        size={14}
                        fill="white"
                    />

                    {item.rating || "4.5"}

                </div>

            </div>

            {/* Content */}

            <div className="p-5">

                <div className="flex justify-between items-start">

                    <div>

                        <h2 className="text-2xl font-bold text-gray-800">

                            {item.name}

                        </h2>

                        <p className="text-gray-500 mt-2">

                            {item.description}

                        </p>

                    </div>

                </div>

                {/* Price */}

                <div className="mt-6 flex justify-between items-center">

                    <h2 className="text-3xl font-black text-orange-500">

                        ₹{item.price}

                    </h2>

                    <div className="flex items-center gap-2 text-gray-500">

                        <Clock3
                            size={18}
                        />

                        {item.preparationTime} mins

                    </div>

                </div>

                {/* Button */}

                <button

                    onClick={() => onAdd(item)}

                    className="
                        w-full
                        mt-6
                        bg-orange-500
                        hover:bg-orange-600
                        text-white
                        py-3
                        rounded-xl
                        flex
                        items-center
                        justify-center
                        gap-2
                        font-semibold
                        transition
                    "

                >

                    <Plus size={20} />

                    Add To Cart

                </button>

            </div>

        </div>

    );

}

export default MenuCard;