import { Star, Clock } from "lucide-react";

function RestaurantBanner({ restaurant }) {

    if (!restaurant) return null;

    return (

        <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-10">

            <img
                src={
                    restaurant.imageUrl ||
                    "https://via.placeholder.com/1200x400"
                }
                className="w-full h-80 object-cover"
                alt={restaurant.name}
            />

            <div className="p-8">

                <h1 className="text-4xl font-bold">

                    {restaurant.name}

                </h1>

                <p className="text-gray-500 mt-2">

                    {restaurant.description}

                </p>

                <div className="flex gap-8 mt-6 flex-wrap">

                    <span className="flex items-center gap-2">

                        <Star
                            className="text-yellow-500"
                            fill="gold"
                        />

                        {restaurant.rating}

                    </span>

                    <span>

                        🍴 {restaurant.cuisine}

                    </span>

                    <span>

                        📍 {restaurant.city}

                    </span>

                    <span className="flex items-center gap-2">

                        <Clock size={18} />

                        {restaurant.deliveryTime} mins

                    </span>

                    <span>

                        🚚 ₹{restaurant.deliveryFee}

                    </span>

                    <span>

                        🛒 Min ₹{restaurant.minimumOrder}

                    </span>

                </div>

            </div>

        </div>

    );

}

export default RestaurantBanner;