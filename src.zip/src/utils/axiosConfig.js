import axios from "axios";

const axiosConfig = axios.create({
    baseURL: "http://localhost:8080",
    headers: {
        "Content-Type": "application/json",
    },
});

axiosConfig.interceptors.request.use((config) => {

    const token = localStorage.getItem("token");

    const publicUrls = [
        "/login",
        "/register",
        "/restaurant-owner/register",
        "/delivery-agent/register"
    ];

    if (token && !publicUrls.includes(config.url)) {
        config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
});

export default axiosConfig;