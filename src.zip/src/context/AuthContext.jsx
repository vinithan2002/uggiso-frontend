import { createContext, useContext, useEffect, useState } from "react";
import authService from "../services/authService";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {

    const [user, setUser] = useState(null);

    const [token, setToken] = useState(
        localStorage.getItem("token") || null
    );

    const [role, setRole] = useState(
        localStorage.getItem("role") || null
    );

    const [loading, setLoading] = useState(false);

    // ================= LOGIN =================

    const login = async (loginData) => {

        try {

            setLoading(true);

            const response = await authService.login(loginData);

            console.log("========== LOGIN RESPONSE ==========");
            console.log(response);
            console.log("===================================");

            localStorage.setItem("token", response.token);
            localStorage.setItem("role", response.role);
            localStorage.setItem("user", JSON.stringify(response));

            setToken(response.token);
            setRole(response.role);
            setUser(response);

            return {
                success: true,
                role: response.role
            };

        } catch (error) {

            console.log("========== LOGIN ERROR ==========");
            console.log(error);
            console.log(error.response);
            console.log(error.response?.data);
            console.log("=================================");

            return {
                success: false,
                message: error.response?.data || error.message
            };

        } finally {

            setLoading(false);

        }

    };

    // ================= REGISTER =================

    const register = async (registerData) => {

        try {

            setLoading(true);

            await authService.register(registerData);

            return {
                success: true
            };

        } catch (error) {

            console.error(error);

            return {
                success: false,
                message: error.response?.data || "Registration Failed"
            };

        } finally {

            setLoading(false);

        }

    };

    // ================= LOGOUT =================

    const logout = () => {

        authService.logout();

        setUser(null);
        setToken(null);
        setRole(null);

    };

    // ================= LOAD USER =================

    useEffect(() => {

        const storedUser = localStorage.getItem("user");

        if (storedUser) {

            setUser(JSON.parse(storedUser));

        }

    }, []);

    return (

        <AuthContext.Provider
            value={{
                user,
                token,
                role,
                loading,
                login,
                register,
                logout
            }}
        >

            {children}

        </AuthContext.Provider>

    );

};

export const useAuth = () => {

    return useContext(AuthContext);

};