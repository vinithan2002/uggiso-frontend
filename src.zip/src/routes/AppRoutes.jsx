import { Routes, Route } from "react-router-dom";

import MainLayout from "../layouts/MainLayout";
import Login from "../pages/auth/Login";
import Register from "../pages/auth/Register";
import Home from "../pages/customer/Home";
import OwnerDashboard from "../pages/owner/Dashboard";
import DeliveryDashboard from "../pages/delivery/Dashboard";
import RestaurantDetails from "../pages/customer/RestaurantDetails";
import ProtectedRoute from "../components/common/ProtectedRoute";
import Cart from "../pages/customer/Cart";
import Orders from "../pages/customer/Orders";
import Profile from "../pages/customer/Profile";

function AppRoutes() {
    return (
        <Routes>

            <Route
                path="/"
                element={
                    <ProtectedRoute
                        allowedRoles={["ROLE_USER"]}
                    >
                        <MainLayout>
                            <Home />
                        </MainLayout>
                    </ProtectedRoute>
                }
            />

            <Route path="/login" element={<Login />} />

            <Route path="/register" element={<Register />} />

            <Route
                path="/owner/dashboard"
                element={
                    <ProtectedRoute
                        allowedRoles={["ROLE_RESTAURANT_OWNER"]}
                    >
                        <OwnerDashboard />
                    </ProtectedRoute>
                }
            />

            <Route
                path="/delivery/dashboard"
                element={
                    <ProtectedRoute
                        allowedRoles={["ROLE_DELIVERY_AGENT"]}
                    >
                        <DeliveryDashboard />
                    </ProtectedRoute>
                }
            />
            <Route
                        path="/restaurant/:id"
                        element={
                            <ProtectedRoute
                                allowedRoles={["ROLE_USER"]}
                            >
                                <MainLayout>
                                    <RestaurantDetails />
                                </MainLayout>
                            </ProtectedRoute>
                        }
                    />

            <Route
                path="/restaurant/:id"
                element={
                    <ProtectedRoute
                        allowedRoles={["ROLE_USER"]}
                    >
                        <MainLayout>
                            <RestaurantDetails />
                        </MainLayout>
                    </ProtectedRoute>
                }
            />

            <Route
                path="/cart"
                element={
                    <ProtectedRoute allowedRoles={["ROLE_USER"]}>
                        <MainLayout>
                            <Cart />
                        </MainLayout>
                    </ProtectedRoute>
                }
            />

            <Route
                path="/orders"
                element={
                    <ProtectedRoute allowedRoles={["ROLE_USER"]}>
                        <MainLayout>
                            <Orders />
                        </MainLayout>
                    </ProtectedRoute>
                }
            />

            <Route
                path="/profile"
                element={
                    <ProtectedRoute allowedRoles={["ROLE_USER"]}>
                        <MainLayout>
                            <Profile />
                        </MainLayout>
                    </ProtectedRoute>
                }
            />
        </Routes>


    );
}

export default AppRoutes;